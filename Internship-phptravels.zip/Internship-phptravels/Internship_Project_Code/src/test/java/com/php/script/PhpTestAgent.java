package com.php.script;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.php.pages.PhpAgentPage;
import com.php.utilities.ExcelUtilities;

public class PhpTestAgent extends PhpBase
{
	PhpAgentPage phpagent;
	
	
	@Test
	  public void validlogin() throws IOException, InterruptedException
	  {   
		  phpagent=new PhpAgentPage(driver);
		  
		   String mail=ExcelUtilities.getcelldata("Agent_Data", 2, 1);
		   String pass=ExcelUtilities.getcelldata("Agent_Data", 3, 1);
		   
		   phpagent.clickAccount();
		   String winHandleBefore = driver.getWindowHandle();    
			  for(String winHandle : driver.getWindowHandles())
			  	{
				    driver.switchTo().window(winHandle);
				}
		   phpagent.setEmail(mail);
		   phpagent.setPassword(pass);
		   phpagent.clickLogin();
		   
		   boolean valid=phpagent.isValidLogIn();
			  Assert.assertTrue(valid);
			  
	  }
	@Test
	  public void Invalidlogin() throws IOException, InterruptedException
	  {   
		phpagent=new PhpAgentPage(driver);
		  
		   String mail=ExcelUtilities.getcelldata("Agent_Data", 4, 1);
		   String pass=ExcelUtilities.getcelldata("Agent_Data", 5, 1);
		   
		   phpagent.clickAccount();
		   String winHandleBefore = driver.getWindowHandle();    
			  for(String winHandle : driver.getWindowHandles())
			  	{
				    driver.switchTo().window(winHandle);
				}
		   phpagent.setEmail(mail);
		   phpagent.setPassword(pass);
		   phpagent.clickLogin();
		   
		   boolean valid=phpagent.isInvalidLogIn();
			  Assert.assertTrue(valid);
			  driver.quit();
			  
	}
	@Test
	  public void Bookings() throws IOException, InterruptedException
	  {
		phpagent=new PhpAgentPage(driver);
		  //validlogin();
		phpagent.clickBookings();
		String actualURL=driver.getCurrentUrl();
		String expectedURL="https://phptravels.net/account/bookings";
		Assert.assertEquals(actualURL, expectedURL);
	  }
	  @Test
	  public void Funds() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickFunds();
		  boolean valid=phpagent.CheckFunds();
		  Assert.assertTrue(valid);
	  }
	  @Test
	  public void MyProfile() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickMyProfile();
		  boolean valid=phpagent.CheckMyProfile();
		  Assert.assertTrue(valid);
	  }
	  @Test
	  public void Logout() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickLogout();
		  boolean valid=phpagent.isInvalidLogIn();
		  Assert.assertTrue(valid);
	  }
	  @Test
	  public void Home() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickHome();
		  String actualURL=driver.getCurrentUrl();
			String expectedURL="https://phptravels.net/";
		  //boolean valid=phpagent.CheckHome();
		  //Assert.assertTrue(valid);
	  }
	  @Test
	  public void Hotel() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickHotel();
		  boolean valid=phpagent.CheckHotel();
		  Assert.assertTrue(valid);
	  }
	  @Test
	  public void Flights() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickFlight();
		  boolean valid=phpagent.CheckFlights();
		  Assert.assertTrue(valid);
	  }
	  @Test
	  public void Tours() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickTours();
		  boolean valid=phpagent.CheckTours();
		  Assert.assertTrue(valid);
	  }
	  @Test
	  public void Visa() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickVisa();
		  boolean valid=phpagent.CheckVisa();
		  Assert.assertTrue(valid);
	  }
	  @Test
	  public void Blog() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  //validlogin();
		  phpagent.clickBlog();
		  boolean valid=phpagent.CheckBlog();
		  Assert.assertTrue(valid);
	  }
	 @Test
		  public void Offers() throws IOException, InterruptedException
		  {
		  phpagent=new PhpAgentPage(driver);
			  //validlogin();
			  phpagent.clickOffers();
			  boolean valid=phpagent.CheckOffers();
			  Assert.assertTrue(valid);
		 }
	  @Test
	  public void HotelSearch() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		  String name=ExcelUtilities.getcelldata("Agent_Data", 8, 1);
		  //validlogin();
		  phpagent.SearchHotel(name);
		  boolean valid=phpagent.CheckHotelSearch();
		  Assert.assertTrue(valid);
	  }
	  @Test
	  public void USD() throws IOException, InterruptedException
	  {
		  phpagent=new PhpAgentPage(driver);
		 // validlogin();
		  phpagent.ChangeUSD();
		  boolean valid=phpagent.CheckUSD();
		  Assert.assertTrue(valid);
		  driver.navigate().back();
	  }
}
