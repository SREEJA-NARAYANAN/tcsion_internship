package com.php.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PhpSupplierPage 
{
	WebDriver driver;
	
	@FindBy(css="input[name='email'][type='text']")
	WebElement email;
	@FindBy(css="input[name='password']")
	WebElement password;
	@FindBy(css="button[type='submit']")
	WebElement login;
	@FindBy(xpath="//h1[text()='Dashboard']")
	WebElement dashboard;
	@FindBy(css="div[class='text-muted']")
	WebElement sales;
	@FindBy(xpath="//h2[text()='Revenue Breakdown 2023']")
	WebElement revenue;
	@FindBy(xpath="//*[@id=\"layoutDrawer_content\"]/main/div/div[2]/div[2]/a/div/div/div")
	WebElement pending;
	@FindBy(css="select[id='booking_status']")
	WebElement pendingtoconfirm;
	@FindBy(xpath="/html/body/nav/div/a/div")
	WebElement dashboard2;
	@FindBy(css="a[aria-controls='toursmodule']")
	WebElement tours;
	@FindBy(css="div[class*='alert']")
	WebElement invalid;
	@FindBy(xpath="//html/body/div[2]/div[2]/main/div/div[2]/div[2]/a/div/div/div/div[1]/div[1]")
	WebElement pending1;
	@FindBy(xpath="//html/body/div[2]/div[2]/main/div/div[2]/div[1]/a/div/div/div/div[1]/div[1]")
	WebElement confirm1;
	@FindBy(id="dropdownMenuProfile")
	WebElement profilebutton;
	@FindBy(xpath="/html/body/nav/div/div/div/div[3]/ul/li[4]/a/div")
	WebElement logout;
	@FindBy(css="a[data-bs-target='#Tours']")
	WebElement tours2;
	
	int pendingcount;
	int confirmcount;
	
	public PhpSupplierPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void setEmail(String mail) 
	{
		email.sendKeys(mail);
		  
	}
	public void setPassword(String pass) 
	{
		password.sendKeys(pass);
		  
	}
	public void clickLogin()
	{
		login.click();
	}
	public boolean CheckDashboard() 
	{
		 boolean valid =dashboard.isDisplayed();
		 return valid;
	}
	public boolean CheckSales() 
	{
		 boolean valid =sales.isDisplayed();
		 return valid;
	}
	public boolean CheckRevenue() 
	{
		 boolean valid =revenue.isDisplayed();
		 return valid;
	}
	public void clickPending()
	{
		//bookings.click();
		
		pendingcount=Integer.parseInt(pending1.getText());
		confirmcount=Integer.parseInt(confirm1.getText());
		pending.click();
		Select sel=new Select(pendingtoconfirm);
		sel.selectByVisibleText("Confirmed");
		driver.navigate().back();
		//dashboard2.click();
	}
	public void clickTours()
	{
		tours.click();
	}
	public void clickLogout()
	{
		profilebutton.click();
		logout.click();
	}
	public boolean isValidLogIn() 
	{
		
		  boolean valid =dashboard.isDisplayed();
		  return valid;
	}
	public boolean isInvalidLogIn() throws InterruptedException 
	{
		  boolean valid =invalid.isDisplayed();
		  return valid;
	}
	public boolean CheckPending() throws InterruptedException 
	{
		Thread.sleep(1000);
		 int pending2=Integer.parseInt(pending1.getText());
		 int confirm2=Integer.parseInt(confirm1.getText());
		 if(pending2==pendingcount-1 && confirm2==confirmcount+1) 
		 	{
			 	return true;
		 	}
		 else
		 	{
			 	return false;
		 	}
		 
	}
	public boolean CheckTours() 
	{
		 boolean valid =tours2.isDisplayed();
		 return valid;
	}

}
