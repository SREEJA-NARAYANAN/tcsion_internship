package com.php.script;

import java.io.IOException;


import org.testng.Assert;
import org.testng.annotations.Test;

import com.php.pages.PhpCustomerPage;
import com.php.utilities.ExcelUtilities;

public class PhpTestCustomer extends PhpBase
	{
	
	PhpCustomerPage phpcustomer;
	
	
  @Test
  public void validlogin() throws IOException, InterruptedException
  {   
	  phpcustomer=new PhpCustomerPage(driver);
	  
	  
	  
	   String mail=ExcelUtilities.getcelldata("Customer_Data", 2, 1);
	   String pass=ExcelUtilities.getcelldata("Customer_Data", 3, 1);
	   
	   phpcustomer.clickAccount();
	   phpcustomer.setEmail(mail);
	   phpcustomer.setPassword(pass);
	  phpcustomer.clickLogin();
	   
	   boolean valid=phpcustomer.isValidLogIn();
		  Assert.assertTrue(valid);
		  
  }
  
  @Test
  public void Invalidlogin() throws IOException, InterruptedException
  {   
	  phpcustomer=new PhpCustomerPage(driver);
	  
	   String mail=ExcelUtilities.getcelldata("Customer_Data", 4, 1);
	   String pass=ExcelUtilities.getcelldata("Customer_Data", 5, 1);
	   
	   phpcustomer.clickAccount();
	   phpcustomer.setEmail(mail);
	   phpcustomer.setPassword(pass);
	   phpcustomer.clickLogin();
	   
	   boolean valid=phpcustomer.isInvalidLogIn();
		  Assert.assertTrue(valid);
		  driver.close();
		  
}
  @Test
  public void Voucher() throws IOException, InterruptedException
  {
	  phpcustomer=new PhpCustomerPage(driver); 
	  //validlogin();
	  phpcustomer.clickVoucher();
	  
	  String winHandleBefore = driver.getWindowHandle();    
	  for(String winHandle : driver.getWindowHandles())
	  	{
		    driver.switchTo().window(winHandle);
		}
	  boolean valid=phpcustomer.CheckVocher();
	  Assert.assertTrue(valid);
	  driver.close();
	  driver.switchTo().window(winHandleBefore);
  }
  @Test
  public void Payment() throws IOException, InterruptedException
  {
	  phpcustomer=new PhpCustomerPage(driver); 
	  //validlogin();
	  phpcustomer.Addfund();
	  boolean valid=phpcustomer.CheckPayment();
	  Assert.assertTrue(valid);
  }
  @Test
  public void Profileupdate() throws IOException, InterruptedException
  {
	  phpcustomer=new PhpCustomerPage(driver); 
	  //validlogin();
	  String Address=ExcelUtilities.getcelldata("Customer_Data", 8, 1);
	  phpcustomer.clickProfile();
	 phpcustomer.setAddress(Address);
	 phpcustomer.clickUpdate();
	 boolean valid=phpcustomer.CheckProfile();
	  Assert.assertTrue(valid);
  }
  @Test
  public void Logout() throws IOException, InterruptedException
  {
	  phpcustomer=new PhpCustomerPage(driver); 
	  //validlogin();
	  phpcustomer.clickLogout();
	  boolean valid=phpcustomer.isInvalidLogIn();
	  Assert.assertTrue(valid);
  }
  @Test
  public void Bookings() throws IOException, InterruptedException
  {
	  phpcustomer=new PhpCustomerPage(driver); 
	  //validlogin();
	  phpcustomer.clickBookings();
	  boolean valid=phpcustomer.CheckBookings();
	  Assert.assertTrue(valid);
  }
  @Test
  public void Funds() throws IOException, InterruptedException
  {
	  phpcustomer=new PhpCustomerPage(driver); 
	  //validlogin();
	  phpcustomer.clickFunds();
	  boolean valid=phpcustomer.CheckPayment();
	  Assert.assertTrue(valid);
  }
  @Test
  public void MyProfile() throws IOException, InterruptedException
  {
	  phpcustomer=new PhpCustomerPage(driver); 
	  //validlogin();
	  phpcustomer.clickMyProfile();
	  boolean valid=phpcustomer.CheckMyProfile();
	  Assert.assertTrue(valid);
  }
	}
