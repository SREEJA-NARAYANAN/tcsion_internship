package com.php.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PhpAdminPage
{
	WebDriver driver;
	
	@FindBy(css="input[name='email'][type='text']")
	 WebElement email;
	@FindBy(css="input[name='password']")
	WebElement password;
	@FindBy(css="button[type='submit']")
	 WebElement login;
	@FindBy(linkText="Bookings")
	 WebElement bookings;
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[1]/div[4]/a/div/div/div")
	WebElement paid;
	@FindBy(xpath="//*[@id=\"data\"]/tbody/tr[1]/td[14]/a")
	WebElement invoice;
	@FindBy(css="h3[class='title']")
	WebElement bookinginvoice;
	@FindBy(xpath="/html/body/div[2]/div[2]/main/div/div[1]/div[3]/a/div/div/div")
	WebElement cancelled;
	@FindBy(xpath="//*[@id=\"data\"]/tbody/tr[1]/td[15]/button")
	WebElement delete;
	@FindBy(xpath="//*[@id=\"layoutDrawer_content\"]/main/div/div[1]/div[2]/a/div/div/div")
	WebElement pending;
	@FindBy(css="select[class*='pending']")
	WebElement pendingtoconfirm;
	@FindBy(linkText="Website")
	WebElement website;
	@FindBy(css="div[class*='uppercase']")
	WebElement dashboard;
	@FindBy(css="div[class*='alert']")
	WebElement invalid;
	@FindBy(xpath="//html/body/div[2]/div[2]/main/div/div[1]/div[3]/a/div/div/div/div[1]/div[1]")
	WebElement delete1;
	@FindBy(xpath="//html/body/div[2]/div[2]/main/div/div[1]/div[2]/a/div/div/div/div[1]/div[1]")
	WebElement pending1;
	@FindBy(xpath="//*[@id=\"layoutDrawer_content\"]/main/div/div[1]/div[1]/a/div/div/div/div[1]/div[1]")
	WebElement confirm1;
	@FindBy(id="dropdownMenuProfile")
	WebElement profilebutton;
	@FindBy(xpath="//html/body/nav/div/div/div/div[3]/ul/li[5]/a/div")
	WebElement logout;
	
	int deletecount;
	int pendingcount;
	int confirmcount;
	
	
	public PhpAdminPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void setEmail(String mail) 
	{
		email.sendKeys(mail);
		  
	}
	public void setPassword(String pass) 
	{
		password.sendKeys(pass);
		  
	}
	public void clickLogin()
	{
		login.click();
	}
	public void clickBookings()
	{
		bookings.click();
		paid.click();
		invoice.click();
	}
	public void clickDelete()
	{
		//bookings.click();
		deletecount=Integer.parseInt(delete1.getText());
		cancelled.click();
		delete.click();
		//String actual=driver.switchTo().alert().getText();
		 driver.switchTo().alert().accept();
		 //return actual;
	}
	public void clickPending()
	{
		//bookings.click();
		pending.click();
		pendingcount=Integer.parseInt(pending1.getText());
		confirmcount=Integer.parseInt(confirm1.getText());
		Select sel=new Select(pendingtoconfirm);
		sel.selectByVisibleText("Confirmed");
	}
	public void clickWebsite()
	{
		website.click();
	}
	public void clickLogout()
	{
		profilebutton.click();
		logout.click();
	}
	
	public boolean isValidLogIn() 
	{
		
		  boolean valid =dashboard.isDisplayed();
		  return valid;
	}
	public boolean isInvalidLogIn() throws InterruptedException 
	{
		  boolean valid =invalid.isDisplayed();
		 return valid;
	}
	public boolean CheckBookings() 
	{
		 boolean valid =bookinginvoice.isDisplayed();
		 return valid;
	}
	public boolean CheckDelete() throws InterruptedException 
	{
		Thread.sleep(1000);
		 int delete2=Integer.parseInt(delete1.getText());
		 if(delete2==deletecount-1) 
		 	{
			 	return true;
		 	}
		 else
		 	{
			 	return false;
		 	}
		 
	}
	public boolean CheckPending() throws InterruptedException 
	{
		Thread.sleep(1000);
		 int pending2=Integer.parseInt(pending1.getText());
		 int confirm2=Integer.parseInt(confirm1.getText());
		 if(pending2==pendingcount-1 && confirm2==confirmcount+1) 
		 	{
			 	return true;
		 	}
		 else
		 	{
			 	return false;
		 	}
		 
	}
	
	
}
