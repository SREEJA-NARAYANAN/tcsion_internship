package com.php.script;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.php.pages.PhpSupplierPage;
import com.php.utilities.ExcelUtilities;

public class PhpTestSupplier extends PhpBase
{
	PhpSupplierPage phpsupplier;
	@Test
	  public void validlogin() throws IOException, InterruptedException
	  {   
		phpsupplier=new PhpSupplierPage(driver);
		  
		   String mail=ExcelUtilities.getcelldata("Supplier_Data", 2, 1);
		   String pass=ExcelUtilities.getcelldata("Supplier_Data", 3, 1);
		   
		   phpsupplier.setEmail(mail);
		   phpsupplier.setPassword(pass);
		   phpsupplier.clickLogin();
		   
		 boolean valid=phpsupplier.isValidLogIn();
		 Assert.assertTrue(valid);
			  
	  }
	@Test
	  public void Invalidlogin() throws IOException, InterruptedException
	  {   
		phpsupplier=new PhpSupplierPage(driver);
		  
		   String mail=ExcelUtilities.getcelldata("Supplier_Data", 4, 1);
		   String pass=ExcelUtilities.getcelldata("Supplier_Data", 5, 1);
		   
		   phpsupplier.setEmail(mail);
		   phpsupplier.setPassword(pass);
		   phpsupplier.clickLogin();
		
		   Boolean valid=phpsupplier.isInvalidLogIn();
		   Assert.assertTrue(valid);
		   driver.close();
			  
	}
	@Test
	  public void Dashboard() throws IOException, InterruptedException 
	  {
		phpsupplier=new PhpSupplierPage(driver);
		  //validlogin();
		  
		  boolean valid=phpsupplier.CheckDashboard();
		  Assert.assertTrue(valid);	
	  }
	@Test
	  public void Sales() throws IOException, InterruptedException 
	  {
		phpsupplier=new PhpSupplierPage(driver);
		  //validlogin();
		  
		  boolean valid=phpsupplier.CheckSales();
		  Assert.assertTrue(valid);	
	  }
	@Test
	  public void Revenue() throws IOException, InterruptedException 
	  {
		phpsupplier=new PhpSupplierPage(driver);
		  //validlogin();
		  
		  boolean valid=phpsupplier.CheckRevenue();
		  Assert.assertTrue(valid);	
	  }
	@Test
	  public void Pending() throws InterruptedException, IOException 
	  {
		phpsupplier=new PhpSupplierPage(driver);
		  //validlogin();
		phpsupplier.clickPending();
		  
		  boolean valid=phpsupplier.CheckPending();
		  Assert.assertTrue(valid);	
	  }
	@Test
	  public void Tours() throws InterruptedException, IOException 
	  {
		phpsupplier=new PhpSupplierPage(driver);
		 //validlogin();
		phpsupplier.clickTours();
		  
		  boolean valid=phpsupplier.CheckTours();
		  Assert.assertTrue(valid);	
		  phpsupplier.clickLogout();
	  }
}
