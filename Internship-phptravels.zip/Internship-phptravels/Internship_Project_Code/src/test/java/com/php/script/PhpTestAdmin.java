package com.php.script;


import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.php.pages.PhpAdminPage;
import com.php.utilities.ExcelUtilities;


public class PhpTestAdmin extends PhpBase
{
	PhpAdminPage phpadmin;
	
	@Test
	  public void validlogin() throws IOException, InterruptedException
	  {   
		  phpadmin=new PhpAdminPage(driver);
		  
		   String mail=ExcelUtilities.getcelldata("Admin_Data", 2, 1);
		   String pass=ExcelUtilities.getcelldata("Admin_Data", 3, 1);
		   
		   phpadmin.setEmail(mail);
		   phpadmin.setPassword(pass);
		   phpadmin.clickLogin();
		   
		 boolean valid=phpadmin.isValidLogIn();
		   Assert.assertTrue(valid);
			  
	  }
	@Test
	  public void Invalidlogin() throws IOException, InterruptedException
	  {   
		phpadmin=new PhpAdminPage(driver);
		  
		   String mail=ExcelUtilities.getcelldata("Admin_Data", 4, 1);
		   String pass=ExcelUtilities.getcelldata("Admin_Data", 5, 1);
		   
		   phpadmin.setEmail(mail);
		   phpadmin.setPassword(pass);
		   phpadmin.clickLogin();
		   Boolean valid=phpadmin.isInvalidLogIn();
		   Assert.assertTrue(valid);
		   driver.close();
			  
	}
	@Test
	  public void Bookings() throws IOException, InterruptedException
	  {
		phpadmin=new PhpAdminPage(driver);
		  //validlogin();
		phpadmin.clickBookings();
		
		String winHandleBefore = driver.getWindowHandle();    
		  for(String winHandle : driver.getWindowHandles())
		  	{
			    driver.switchTo().window(winHandle);
			}
		
		  boolean valid=phpadmin.CheckBookings();
		  Assert.assertTrue(valid);
		  Thread.sleep(200);
		  driver.close();
		  driver.switchTo().window(winHandleBefore);
		
	  }
	@Test
	  public void Delete() throws IOException, InterruptedException
	  {
		phpadmin=new PhpAdminPage(driver);
		  //validlogin();
		  
		phpadmin.clickDelete();
		
		  boolean valid=phpadmin.CheckDelete();
		  Assert.assertTrue(valid);	
	  }
	@Test
	  public void Pending() throws IOException, InterruptedException
	  {
		phpadmin=new PhpAdminPage(driver);
		  //validlogin();
		phpadmin.clickPending();
		
		  boolean valid=phpadmin.CheckPending();
		  Assert.assertTrue(valid);	
	  }
	@Test
	  public void Website() throws IOException, InterruptedException
	  {
		phpadmin=new PhpAdminPage(driver);
		  //validlogin();
		phpadmin.clickWebsite();
		
		String winHandleBefore = driver.getWindowHandle();    
		  for(String winHandle : driver.getWindowHandles())
		  	{
			    driver.switchTo().window(winHandle);
			}
		String actualURL=driver.getCurrentUrl();
		String expectedURL="https://phptravels.net/sd";
		Assert.assertEquals(actualURL, expectedURL);
		driver.close();
		driver.switchTo().window(winHandleBefore);
		phpadmin.clickLogout();
		
	  }
}
