package com.php.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PhpAgentPage 
{
	WebDriver driver;
	
	@FindBy(id="ACCOUNT")
	 WebElement account;
	@FindBy(linkText="Agents Login")
	 WebElement agent;
	@FindBy(css="input[placeholder='Email']")
	 WebElement email;
	@FindBy(css="input[placeholder='Password']")
	 WebElement password;
	@FindBy(css="button[class*='btn-lg']")
	 WebElement login;
	@FindBy(linkText="My Bookings")
	 WebElement bookings;
	@FindBy(linkText="Add Funds")
	 WebElement funds;
	@FindBy(linkText="My Profile")
	 WebElement profile;
	@FindBy(linkText="Logout")
	 WebElement logout;
	@FindBy(css="img[alt='logo'][style*='height']")
	 WebElement home;
	@FindBy(linkText="Hotels")
	 WebElement hotel;
	@FindBy(css="a[title='flights']")
	 WebElement flights;
	@FindBy(linkText="Tours")
	 WebElement tours;
	@FindBy(css="a[title='visa']")
	 WebElement visa;
	@FindBy(linkText="Blog")
	 WebElement blog;
	@FindBy(linkText="Offers")
	 WebElement offers;
	@FindBy(id="select2-hotels_city-container")
	 WebElement searchcity;
	@FindBy(css="input[type='search']")
	 WebElement textbox;
	@FindBy(css="li[role='option']")
	 WebElement city;
	@FindBy(id="submit")
	 WebElement searchbutton;
	@FindBy(id="currency")
	 WebElement usd;
	@FindBy(linkText="INR")
	 WebElement inr;
	@FindBy(css="button[type='submit'][class*='my-3']")
	 WebElement paynow;
	@FindBy(css="input[name='firstname']")
	WebElement name;
	@FindBy(linkText="Signup")
	 WebElement signup;
	@FindBy(css="h2[class='text-center']")
	WebElement besthotels;
	@FindBy(css="label[for='one-way']")
	WebElement bestflights;
	@FindBy(css="h2[class='text-center']")
	WebElement tourpackages;
	@FindBy(css="button[aria-expanded='true']")
	WebElement modifysearchcity;
	@FindBy(xpath="//h2[text()='Submit Your Visa Today!']")
	WebElement searchvisa;
	@FindBy(xpath="//h2[text()='PHPTRAVELS Blog']")
	WebElement searchblog;
	@FindBy(xpath="//h2[text()='PHPTRAVELS Offers']")
	WebElement searchoffers;
	@FindBy(linkText="Dashboard")
	 WebElement Dashboard;
	@FindBy(xpath="//html/body/header/div/div/div/div/div/div[2]/div/div[2]/div[3]/div/button")
	WebElement newaccount;
	
	
	public PhpAgentPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	public void clickAccount() throws InterruptedException
{  
		Thread.sleep(200);
		account.click();
		agent.click();
	}
	public void setEmail(String mail) 
	{
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(100));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[placeholder='Email']")));
		email.sendKeys(mail);
		  
	}
	public void setPassword(String pass) 
	{
		password.sendKeys(pass);
		  
	}
	public void clickLogin()
	{
		login.click();
	}
	public void clickBookings()
	{
		bookings.click();
	}
	public void clickFunds()
	{
		funds.click();
	}
	public void clickMyProfile()
	{
		profile.click();
	}
	public void clickLogout()
	{
		newaccount.click();
		Dashboard.click();
		logout.click();
	}
	public void clickHome()
	{
		home.click();
	}
	public void clickHotel()
	{
		hotel.click();
	}
	public void clickFlight()
	{
		
		flights.click();
	}
	public void clickTours()
	{
		tours.click();
	}
	public void clickVisa()
	{
		visa.click();
	}
	public void clickBlog()
	{
		blog.click();
	}
	public void clickOffers()
	{
		offers.click();
	}
	public void SearchHotel(String name) throws InterruptedException
	{
		hotel.click();
		searchcity.click();
		textbox.sendKeys(name);
		Thread.sleep(5000);
		city.click();
		Thread.sleep(800);
		searchbutton.click();
	}
	public void ChangeUSD()
	{
		usd.click();
		inr.click();
	}
	
	public boolean isValidLogIn() 
	{
		  boolean valid =Dashboard.isDisplayed();
		return valid;
	}
	public boolean isInvalidLogIn() 
	{
		  boolean valid =signup.isDisplayed();
		return valid;
	}
	public boolean CheckFunds() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =paynow.isDisplayed();
		return valid;
	}
	public boolean CheckMyProfile() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =name.isDisplayed();
		return valid;
	}
	public boolean CheckHotel() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =besthotels.isDisplayed();
		return valid;
	}
	public boolean CheckFlights() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =bestflights.isDisplayed();
		return valid;
	}
	public boolean CheckTours() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =tourpackages.isDisplayed();
		return valid;
	}
	public boolean CheckVisa() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =searchvisa.isDisplayed();
		return valid;
	}
	public boolean CheckBlog() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =searchblog.isDisplayed();
		return valid;
	}
	public boolean CheckOffers() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =searchoffers.isDisplayed();
		return valid;
	}
	public boolean CheckHotelSearch() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =modifysearchcity.isDisplayed();
		return valid;
	}
	public boolean CheckUSD() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =usd.isDisplayed();
		return valid;
	}

}
