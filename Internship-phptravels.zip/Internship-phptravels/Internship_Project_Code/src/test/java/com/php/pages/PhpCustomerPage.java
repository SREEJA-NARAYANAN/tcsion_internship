package com.php.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PhpCustomerPage 
{
	WebDriver driver;
	
	@FindBy(id="ACCOUNT")
	 WebElement account;
	@FindBy(linkText="Customer Login")
	 WebElement customer;
	@FindBy(css="input[placeholder='Email']")
	 WebElement email;
	@FindBy(css="input[placeholder='Password']")
	 WebElement password;
	@FindBy(css="button[class*='btn-lg']")
	 WebElement login;
	@FindBy(linkText="My Bookings")
	 WebElement bookings;
	@FindBy(linkText="Add Funds")
	 WebElement funds;
	@FindBy(linkText="My Profile")
	 WebElement profile;
	@FindBy(linkText="Logout")
	 WebElement logout;
	@FindBy(linkText="View Voucher")
	 WebElement voucher;
	@FindBy(id="gateway_paypal")
	 WebElement paypal;
	@FindBy(css="button[type='submit'][class*='my-3']")
	 WebElement paynow;
	@FindBy(css="input[name='address1']")
	 WebElement address;
	@FindBy(css="button[type='submit'][class$='effect']")
	 WebElement update;
	@FindBy(linkText="Dashboard")
	 WebElement Dashboard;
	@FindBy(linkText="Signup")
	 WebElement signup;
	@FindBy(id="download")
	 WebElement download;
	@FindBy(css="div[class='btn-front']")
	 WebElement back;
	@FindBy(css="div[class*='success']")
	 WebElement success;
	@FindBy(id="cookie_stop")
	 WebElement cookies;
	@FindBy(css="input[name='firstname']")
	WebElement name;
	@FindBy(linkText="Yes")
	 WebElement yes;
	
	
	public PhpCustomerPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	public void clickAccount() throws InterruptedException
	{  
		Thread.sleep(200);
		account.click();
		customer.click();
	}
	public void setEmail(String mail) 
	{
		email.sendKeys(mail);
		  
	}
	public void setPassword(String pass) 
	{
		password.sendKeys(pass);
		  
	}
	public void clickLogin()
	{
		login.click();
	}
	public void clickVoucher()
	{
		bookings.click();
		voucher.click();
		
	}
	public void Addfund() throws InterruptedException
	{
		funds.click();
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(100));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("gateway_paypal")));
		cookies.click();
		paypal.click();
		paynow.click();
		driver.navigate().back();	
	}
	public void clickProfile()
	{
		profile.click();
		address.clear();
	}
	public void setAddress(String Address)
	{
		
		address.sendKeys(Address);
	}
	public void clickUpdate()
	{
		update.click();
	}
	public void clickLogout()
	{
		logout.click();
	}
	public void clickBookings()
	{
		bookings.click();
	}
	public void clickFunds()
	{
		funds.click();
	}
	public void clickMyProfile()
	{
		profile.click();
	}
	
	public boolean isValidLogIn() throws InterruptedException 
	{
		Thread.sleep(1000);
		  boolean valid =Dashboard.isDisplayed();
		return valid;
	}
	
	public boolean isInvalidLogIn() 
	{
		  boolean valid =signup.isDisplayed();
		return valid;
	}
	public boolean CheckVocher() throws InterruptedException 
	{
		boolean valid =download.isDisplayed();
		return valid;
	}
	public boolean CheckPayment() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =paynow.isDisplayed();
		return valid;
	}
	public boolean CheckProfile() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =success.isDisplayed();
		return valid;
	}
	public boolean CheckBookings() throws InterruptedException 
	{
		Thread.sleep(200);
		  boolean valid =voucher.isDisplayed();
		return valid;
	}
	
	public boolean CheckMyProfile() throws InterruptedException 
	{
		Thread.sleep(500);
		  boolean valid =name.isDisplayed();
		return valid;
	}
}
